//
//  GameScene.swift
//  new
//
//  Created by Rui Xu on 3/6/17.
//  Copyright © 2017 Rui Xu. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    
    override func didMove (to view: SKView){
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        
        let scene = SKScene(fileNamed: "GameOver")
        // Set the scale mode to scale to fit the window
        scene?.scaleMode = .aspectFill
        
        // Present the scene
        view?.presentScene(scene)
    }
    
}
